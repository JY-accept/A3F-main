"""
A3F Training Entry Point
========================
Launches the Adversarial-Aware Adaptive Filtering (A3F) training loop using
🤗 Accelerate for distributed / mixed-precision training.

Usage example (single node, 4 GPUs):
    accelerate launch train.py \\
        --model_name_or_path  /path/to/llama-3-7b \\
        --train_file_path     data/train.json \\
        --validation_file_path data/dev.json \\
        --output_dir          checkpoints/a3f \\
        --log_path            logs/a3f \\
        --train_data_cache    a3f/data/temp.json \\
        --num_train_epochs    3 \\
        --learning_rate       5e-6 \\
        --per_device_train_batch_size 1 \\
        --gradient_accumulation_steps 4 \\
        --w_gen 0.7 --w_cls 0.3 --w_reg 0.5 \\
        --do_train --do_validation
"""

import logging
import os
from datetime import timedelta

import torch
from accelerate import Accelerator
from accelerate.logging import get_logger
from accelerate.utils import InitProcessGroupKwargs

from a3f.utils.config import args
from a3f.trainer.a3f_trainer import A3FTrainer

# ── Accelerator ───────────────────────────────────────────────────────────────
kwargs = InitProcessGroupKwargs(timeout=timedelta(seconds=5400))
accelerator = Accelerator(
    gradient_accumulation_steps=args.gradient_accumulation_steps,
    kwargs_handlers=[kwargs],
)
args.gradient_accumulation_steps = accelerator.gradient_accumulation_steps

# ── Logging ───────────────────────────────────────────────────────────────────
os.makedirs(args.log_path, exist_ok=True)
log_filename = "train.log" if args.do_train else "eval.log"

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
    filename=os.path.join(args.log_path, log_filename),
)
logger = get_logger(__name__)

args_message = "\n" + "\n".join(
    f"{k:<40}: {v}" for k, v in vars(args).items()
)
logger.info(args_message, main_process_only=True)
accelerator.print(args_message)

# ── Run ───────────────────────────────────────────────────────────────────────
trainer = A3FTrainer(accelerator)

accelerator.wait_for_everyone()

if args.do_train:
    model = trainer.train()
    accelerator.print("Training complete.")
