"""
A3F Evaluation Entry Point
===========================
Runs inference and computes EM / F1 scores for the A3F model.

Evaluation modes (pass exactly one flag):
  --wo_retrieval         No retrieved context.
  --w_one_retrieval      Single context (--retrieve_type selects which kind).
  --w_noisy_retrieval    Mixed context list at --noise_ratio proportion.

Example – evaluate on golden + 40 % irrelevant noise:
    python evaluate.py \\
        --test_model_name_or_path checkpoints/a3f/epoch_2.bin \\
        --test_data_path          data/test_nq.json \\
        --w_noisy_retrieval \\
        --noise_ratio 0.4 \\
        --result_save             results/nq_noisy_40.json
"""

from a3f.utils.config import args
from a3f.evaluate.evaluator import (
    evaluate_wo_retrieval,
    evaluate_w_one_retrieval,
    evaluate_w_noisy_retrieval,
)

if args.wo_retrieval:
    evaluate_wo_retrieval(
        args=args,
        data_path=args.test_data_path,
        result_save=args.result_save,
    )

elif args.w_one_retrieval:
    evaluate_w_one_retrieval(
        args=args,
        data_path=args.test_data_path,
        retrieve_type=args.retrieve_type,
        save_cache=args.selected_retrieve_cache,
        result_save=args.result_save,
    )

elif args.w_noisy_retrieval:
    evaluate_w_noisy_retrieval(
        args=args,
        data_path=args.test_data_path,
        noise_ratio=args.noise_ratio if args.noise_ratio is not None else 0.4,
        save_cache=args.selected_retrieve_cache,
        result_save=args.result_save,
    )

else:
    print(
        "No evaluation mode specified.  "
        "Use --wo_retrieval, --w_one_retrieval, or --w_noisy_retrieval."
    )
