#!/usr/bin/env bash
# =============================================================================
# A3F Training Script
# =============================================================================
# Trains the Adversarial-Aware Adaptive Filtering (A3F) model on four NVIDIA
# A100 80 GB GPUs using Accelerate + DeepSpeed ZeRO.
#
# Usage:
#   cd A3F/scripts
#   bash train.sh
# =============================================================================

set -euo pipefail

export NCCL_P2P_LEVEL="NVL"
export OMP_NUM_THREADS=16

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# ── Paths ─────────────────────────────────────────────────────────────────────
MODEL_PATH=""          # << set to your LLaMA-3-7B or DeepSeek-R1-7B checkpoint
TRAIN_DATA="$ROOT_DIR/data/train.json"
DEV_DATA="$ROOT_DIR/data/dev.json"
OUTPUT_DIR="$ROOT_DIR/checkpoints/a3f"
LOG_DIR="$ROOT_DIR/logs/a3f"
TRAIN_CACHE="$ROOT_DIR/a3f/data/temp.json"

mkdir -p "$OUTPUT_DIR" "$LOG_DIR"

# ── Accelerate config (run once manually if not already configured) ───────────
# accelerate config

# ── Launch ────────────────────────────────────────────────────────────────────
CUDA_VISIBLE_DEVICES=0,1,2,3 accelerate launch \
    --num_processes 4 \
    --mixed_precision bf16 \
    "$ROOT_DIR/train.py" \
        --model_name_or_path        "$MODEL_PATH" \
        --train_file_path           "$TRAIN_DATA" \
        --validation_file_path      "$DEV_DATA" \
        --output_dir                "$OUTPUT_DIR" \
        --log_path                  "$LOG_DIR" \
        --train_data_cache          "$TRAIN_CACHE" \
        --seed                      42 \
        --num_train_epochs          3 \
        --training_stage_num        4 \
        --learning_rate             5e-6 \
        --per_device_train_batch_size  1 \
        --per_device_eval_batch_size   4 \
        --gradient_accumulation_steps  4 \
        --max_length                4096 \
        --w_gen                     0.7 \
        --w_cls                     0.3 \
        --w_reg                     0.5 \
        --knn_k                     5 \
        --ig_threshold              0.3 \
        --checkpointing_step        600 \
        --do_train \
        --do_validation
