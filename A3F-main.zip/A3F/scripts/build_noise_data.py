"""
Noise Corpus Construction Script  (Section 3.2 of the A3F paper, Algorithm 1)
==============================================================================
Builds the four-type noise dataset from a raw QA benchmark.

Input JSON format (list of dicts):
  {
    "question":   str,
    "answers":    list[str],
    "best_ctx":   {"text": str, ...},     # golden document
    "ctxs":       [{"text": str, "has_answer": bool}, ...],
    "counter_fac": [str, ...]             # optional counterfactual passages
  }

Output JSON format (list of dicts):
  {
    "question":      str,
    "answers":       list[str],
    "best_ctx":      dict,
    "ad_ctx":        [relevant_ctx, counterfactual_ctx, irrelevant_ctx],
    "redundant_ctx": dict
  }

Usage:
    python scripts/build_noise_data.py \\
        --input_path  data/raw_train.json \\
        --output_path data/train.json \\
        --split       train

Dependencies:
  - openai  (for GPT-4-based gold augmentation, optional)
  - tqdm
"""

import argparse
import json
import random
import re
from typing import List, Dict, Optional

from tqdm import tqdm


# ─────────────────────────────────────────────────────────────────────────────
# Text utilities
# ─────────────────────────────────────────────────────────────────────────────

def _has_anaphora_ambiguity(question: str) -> bool:
    """Very conservative heuristic: flag questions with unresolved pronouns."""
    pronouns = re.compile(
        r"\b(he|she|it|they|his|her|their|its|him|them)\b", re.IGNORECASE
    )
    return bool(pronouns.search(question))


def _normalize_text(text: str) -> str:
    """Remove non-semantic formatting characters."""
    text = re.sub(r"[\r\n\t]+", " ", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip()


def _split_sentences(text: str) -> List[str]:
    """Naive sentence splitter."""
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


# ─────────────────────────────────────────────────────────────────────────────
# Step 1 – QA pair filtering
# ─────────────────────────────────────────────────────────────────────────────

def filter_qa_pairs(data: List[Dict]) -> List[Dict]:
    """Remove ambiguous / low-quality QA pairs (Section 3.2, Step 1)."""
    filtered = []
    for sample in data:
        q = sample.get("question", "").strip()
        answers = sample.get("answers", [])

        # Must have a question and at least one unique answer
        if not q or not answers:
            continue

        # Skip anaphora ambiguity
        if _has_anaphora_ambiguity(q):
            continue

        # Require a unique, non-empty reference answer
        unique_answers = list({a.strip() for a in answers if a.strip()})
        if not unique_answers:
            continue

        sample["answers"] = unique_answers
        sample["question"] = _normalize_text(q)
        filtered.append(sample)

    print(f"Filtered: {len(data)} → {len(filtered)} samples.")
    return filtered


# ─────────────────────────────────────────────────────────────────────────────
# Step 2 – Golden text augmentation (synonym / syntactic rewrite)
# ─────────────────────────────────────────────────────────────────────────────

def _synonym_substitute(text: str, prob: float = 0.20) -> str:
    """Very lightweight synonym substitution using a small lookup table.

    In production, replace with a proper lexical resource (e.g. WordNet).
    """
    simple_synonyms = {
        "important": "crucial",
        "shows": "demonstrates",
        "large": "substantial",
        "small": "minor",
        "use": "employ",
        "help": "assist",
        "make": "create",
        "found": "discovered",
        "known": "recognised",
        "area": "region",
    }
    tokens = text.split()
    result = []
    for tok in tokens:
        lower = tok.lower()
        if lower in simple_synonyms and random.random() < prob:
            replacement = simple_synonyms[lower]
            # Preserve capitalisation
            if tok[0].isupper():
                replacement = replacement.capitalize()
            result.append(replacement)
        else:
            result.append(tok)
    return " ".join(result)


def augment_golden_text(text: str) -> str:
    """Apply synonym substitution to the golden document (Step 2).

    For full quality, use GPT-4 syntactic rewriting (requires ``openai``).
    """
    return _synonym_substitute(text, prob=0.20)


# ─────────────────────────────────────────────────────────────────────────────
# Step 3 – Four-type noise construction
# ─────────────────────────────────────────────────────────────────────────────

def build_relevant_noise(sample: Dict) -> Optional[Dict]:
    """Relevant noise: contextually close but corrupts the answer entity.

    Selects the first passage in ``ctxs`` that has_answer=False.
    Falls back to entity-substituted gold if no such passage exists.
    """
    golden_text = sample["best_ctx"].get("text", "")
    without_answer = [
        c for c in sample.get("ctxs", []) if not c.get("has_answer")
    ]
    if without_answer:
        ctx = without_answer[0]
    else:
        # Fallback: corrupt the gold text
        corrupted = _synonym_substitute(golden_text, prob=0.5)
        ctx = {"text": corrupted, "has_answer": False}
    return ctx


def build_counterfactual_noise(sample: Dict) -> Optional[Dict]:
    """Counterfactual noise: contains factually wrong but coherent content."""
    if sample.get("counter_fac"):
        cf_text = random.choice(sample["counter_fac"])
        return {"text": cf_text, "has_answer": False}

    # Construct a counterfactual by swapping answer entities with random words
    golden_text = sample["best_ctx"].get("text", "")
    answers = sample.get("answers", ["unknown"])
    target = answers[0]
    # Replace the answer entity with a plausible-sounding placeholder
    cf_text = golden_text.replace(target, f"<COUNTERFACTUAL_{target[:3].upper()}>")
    return {"text": cf_text, "has_answer": False}


def build_redundant_noise(sample: Dict, all_data: List[Dict]) -> Optional[Dict]:
    """Redundant noise: same topic but no direct answer (low-relevance passage).

    Uses non-answer passages from ctxs; if none, samples from same-topic docs.
    """
    without_answer = [
        c for c in sample.get("ctxs", []) if not c.get("has_answer")
    ]
    if len(without_answer) > 1:
        return without_answer[1]   # Second non-answer passage
    if without_answer:
        return without_answer[0]
    # Fallback: random passage from any retrieved context
    for other in random.sample(all_data, min(5, len(all_data))):
        if other is not sample and other.get("ctxs"):
            c = random.choice(other["ctxs"])
            if not c.get("has_answer"):
                return c
    return None


def build_irrelevant_noise(
    sample: Dict, all_data: List[Dict], sample_idx: int
) -> Optional[Dict]:
    """Irrelevant noise: from a completely different query."""
    other_indices = [i for i in range(len(all_data)) if i != sample_idx]
    for idx in random.sample(other_indices, min(10, len(other_indices))):
        other = all_data[idx]
        ctxs = other.get("ctxs", [])
        if ctxs:
            return random.choice(ctxs)
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Full pipeline
# ─────────────────────────────────────────────────────────────────────────────

def build_noise_corpus(
    data: List[Dict],
    verbose: bool = True,
) -> List[Dict]:
    """Algorithm 1 – construct four-type noise corpus.

    Returns enriched samples where ``ad_ctx`` holds
    [relevant, counterfactual, irrelevant] and ``redundant_ctx`` holds the
    redundant noise document.
    """
    result = []
    for idx, sample in enumerate(tqdm(data, desc="Building noise corpus",
                                      disable=not verbose)):
        best_ctx = sample.get("best_ctx")
        if isinstance(best_ctx, list):
            best_ctx = best_ctx[0]
        if not best_ctx:
            continue

        # Augment golden text
        augmented_text = augment_golden_text(best_ctx.get("text", ""))
        augmented_best = {**best_ctx, "text": augmented_text}

        # Build four noise types
        relevant      = build_relevant_noise(sample)
        counterfactual = build_counterfactual_noise(sample)
        redundant     = build_redundant_noise(sample, data)
        irrelevant    = build_irrelevant_noise(sample, data, idx)

        # Fallback: re-use golden text if construction fails
        fallback = {"text": best_ctx.get("text", ""), "has_answer": False}
        relevant      = relevant      or fallback
        counterfactual = counterfactual or fallback
        redundant     = redundant     or fallback
        irrelevant    = irrelevant    or fallback

        result.append({
            "question":      sample["question"],
            "answers":       sample["answers"],
            "best_ctx":      augmented_best,
            "ad_ctx":        [relevant, counterfactual, irrelevant],
            "redundant_ctx": redundant,
            # Preserve original fields for downstream use
            "ctxs":          sample.get("ctxs", []),
            "counter_fac":   sample.get("counter_fac", []),
        })

    return result


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        description="Build the A3F four-type noise corpus."
    )
    parser.add_argument("--input_path",  required=True,
                        help="Path to raw QA JSON file.")
    parser.add_argument("--output_path", required=True,
                        help="Where to save the processed JSON.")
    parser.add_argument("--split", default="train",
                        choices=["train", "dev", "test"],
                        help="Dataset split label (for logging only).")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


if __name__ == "__main__":
    import sys
    sys.path.insert(0, __file__.replace("/scripts/build_noise_data.py", ""))

    cli_args = parse_args()
    random.seed(cli_args.seed)

    print(f"Loading {cli_args.split} data from {cli_args.input_path} …")
    with open(cli_args.input_path, encoding="utf-8") as fh:
        raw_data = json.load(fh)

    print("Filtering QA pairs …")
    filtered = filter_qa_pairs(raw_data)

    print("Constructing noise corpus …")
    processed = build_noise_corpus(filtered)

    with open(cli_args.output_path, "w", encoding="utf-8") as fh:
        json.dump(processed, fh, ensure_ascii=False, indent=2)

    print(f"Saved {len(processed)} samples to {cli_args.output_path}")
