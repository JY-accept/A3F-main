#!/usr/bin/env bash
# =============================================================================
# A3F Evaluation Script
# =============================================================================
# Runs evaluation across all four retrieval settings used in the paper
# (Table 3):  golden, relevant noise, counterfactual noise, irrelevant noise.
#
# Usage:
#   cd A3F/scripts
#   bash evaluate.sh
# =============================================================================

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

MODEL=""               # << set to your fine-tuned A3F checkpoint path
TEST_DATA="$ROOT_DIR/data/test.json"
RESULT_DIR="$ROOT_DIR/results/a3f"
CACHE_DIR="$ROOT_DIR/cache"

mkdir -p "$RESULT_DIR" "$CACHE_DIR"

# ── 1. Golden retrieval (no noise) ───────────────────────────────────────────
echo "==> Evaluating: golden retrieval"
CUDA_VISIBLE_DEVICES=0 python3 "$ROOT_DIR/evaluate.py" \
    --w_one_retrieval \
    --retrieve_type           best \
    --test_model_name_or_path "$MODEL" \
    --test_data_path          "$TEST_DATA" \
    --selected_retrieve_cache "$CACHE_DIR/golden.json" \
    --result_save             "$RESULT_DIR/golden.json"

# ── 2. Golden + relevant noise ────────────────────────────────────────────────
echo "==> Evaluating: golden + relevant noise"
CUDA_VISIBLE_DEVICES=0 python3 "$ROOT_DIR/evaluate.py" \
    --w_one_retrieval \
    --retrieve_type           relevant \
    --test_model_name_or_path "$MODEL" \
    --test_data_path          "$TEST_DATA" \
    --selected_retrieve_cache "$CACHE_DIR/relevant.json" \
    --result_save             "$RESULT_DIR/relevant.json"

# ── 3. Golden + counterfactual noise ─────────────────────────────────────────
echo "==> Evaluating: golden + counterfactual noise"
CUDA_VISIBLE_DEVICES=0 python3 "$ROOT_DIR/evaluate.py" \
    --w_one_retrieval \
    --retrieve_type           counterfactual \
    --test_model_name_or_path "$MODEL" \
    --test_data_path          "$TEST_DATA" \
    --selected_retrieve_cache "$CACHE_DIR/counterfactual.json" \
    --result_save             "$RESULT_DIR/counterfactual.json"

# ── 4. Golden + redundant noise ───────────────────────────────────────────────
echo "==> Evaluating: golden + redundant noise"
CUDA_VISIBLE_DEVICES=0 python3 "$ROOT_DIR/evaluate.py" \
    --w_one_retrieval \
    --retrieve_type           redundant \
    --test_model_name_or_path "$MODEL" \
    --test_data_path          "$TEST_DATA" \
    --selected_retrieve_cache "$CACHE_DIR/redundant.json" \
    --result_save             "$RESULT_DIR/redundant.json"

# ── 5. Golden + irrelevant noise ─────────────────────────────────────────────
echo "==> Evaluating: golden + irrelevant noise"
CUDA_VISIBLE_DEVICES=0 python3 "$ROOT_DIR/evaluate.py" \
    --w_one_retrieval \
    --retrieve_type           irrelevant \
    --test_model_name_or_path "$MODEL" \
    --test_data_path          "$TEST_DATA" \
    --selected_retrieve_cache "$CACHE_DIR/irrelevant.json" \
    --result_save             "$RESULT_DIR/irrelevant.json"

# ── 6. Robustness: mixed 40 % noise (Section 4.2.4) ──────────────────────────
echo "==> Robustness evaluation: 40% noise ratio"
CUDA_VISIBLE_DEVICES=0 python3 "$ROOT_DIR/evaluate.py" \
    --w_noisy_retrieval \
    --noise_ratio             0.4 \
    --test_model_name_or_path "$MODEL" \
    --test_data_path          "$TEST_DATA" \
    --result_save             "$RESULT_DIR/noisy_40pct.json"

# ── 7. Robustness: mixed 60 % noise ──────────────────────────────────────────
echo "==> Robustness evaluation: 60% noise ratio"
CUDA_VISIBLE_DEVICES=0 python3 "$ROOT_DIR/evaluate.py" \
    --w_noisy_retrieval \
    --noise_ratio             0.6 \
    --test_model_name_or_path "$MODEL" \
    --test_data_path          "$TEST_DATA" \
    --result_save             "$RESULT_DIR/noisy_60pct.json"

echo "All evaluations complete. Results saved to $RESULT_DIR"
