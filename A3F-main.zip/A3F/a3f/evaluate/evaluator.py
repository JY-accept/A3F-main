"""
Evaluation utilities for the A3F framework.

Supports:
  - Without retrieval
  - Single retrieved context (any noise type)
  - Mixed noisy retrieval
"""

from __future__ import annotations

import json
from typing import List, Dict, Optional, Tuple

from a3f.metrics.em_f1 import compute_metrics
from a3f.utils.answer_processor import (
    extract_answer,
    vllm_wo_retrieval,
    vllm_w_one_retrieval,
    vllm_w_noisy_retrieval,
)
from a3f.utils.noise_constructor import (
    select_one_retrieve,
    select_noisy_retrieval,
)
from a3f.utils.loader import load_data


# ─────────────────────────────────────────────────────────────────────────────
# Shared scoring helper
# ─────────────────────────────────────────────────────────────────────────────

def _score_predictions(
    data: List[Dict],
    predictions: List[str],
    result_save: Optional[str] = None,
) -> Tuple[float, float]:
    """Attach EM / F1 scores to each sample and return macro averages."""
    f1_list, em_list = [], []

    for sample, raw_pred in zip(data, predictions):
        ans = extract_answer(raw_pred)
        if ans:
            metrics = compute_metrics(ans, sample["answers"])
            f1 = metrics["f1"]
            em = metrics["em"]
        else:
            f1, em = 0.0, 0.0

        sample["f1"] = f1
        sample["em"] = em
        sample["prediction"] = ans or ""
        f1_list.append(f1)
        em_list.append(em)

    avg_f1 = sum(f1_list) / len(f1_list) if f1_list else 0.0
    avg_em = sum(em_list) / len(em_list) if em_list else 0.0

    if result_save:
        with open(result_save, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)

    print({"f1": avg_f1, "em": avg_em})
    return avg_f1, avg_em


# ─────────────────────────────────────────────────────────────────────────────
# Evaluation functions
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_wo_retrieval(
    args,
    data_path: str,
    result_save: Optional[str] = None,
) -> Tuple[float, float]:
    """Evaluate the model without any retrieved context."""
    data = load_data(data_path)
    predictions = vllm_wo_retrieval(args, data)
    return _score_predictions(data, predictions, result_save)


def evaluate_w_one_retrieval(
    args,
    data_path: str,
    retrieve_type: str = "best",
    save_cache: Optional[str] = None,
    result_save: Optional[str] = None,
) -> Tuple[float, float]:
    """Evaluate with a single retrieved context per sample.

    Args:
        retrieve_type: One of ``best``, ``relevant``, ``counterfactual``,
            ``redundant``, ``irrelevant``.
    """
    raw_data = load_data(data_path)
    data = select_one_retrieve(raw_data, retrieve_type=retrieve_type,
                               save_cache=save_cache)
    predictions = vllm_w_one_retrieval(args, data)
    return _score_predictions(data, predictions, result_save)


def evaluate_w_noisy_retrieval(
    args,
    data_path: str,
    noise_ratio: float = 0.4,
    save_cache: Optional[str] = None,
    result_save: Optional[str] = None,
) -> Tuple[float, float]:
    """Evaluate with a mixed noisy retrieval context.

    Args:
        noise_ratio: Fraction of noisy passages in each sample's context list.
    """
    raw_data = load_data(data_path)
    data = select_noisy_retrieval(raw_data, noise_ratio=noise_ratio,
                                  save_cache=save_cache)
    predictions = vllm_w_noisy_retrieval(args, data)
    return _score_predictions(data, predictions, result_save)


# ─────────────────────────────────────────────────────────────────────────────
# Validation-time helper (used inside A3FTrainer)
# ─────────────────────────────────────────────────────────────────────────────

def infer_evaluate(data: List[Dict]) -> Tuple[float, float]:
    """Compute macro-average F1 and EM from samples that already carry
    an ``infer`` field (set by ``A3FTrainer._run_validation``).
    """
    f1_list, em_list = [], []
    for sample in data:
        raw = sample.get("infer", "")
        ans = extract_answer(raw)
        if ans:
            metrics = compute_metrics(ans, sample["answers"])
            f1_list.append(metrics["f1"])
            em_list.append(metrics["em"])
        else:
            f1_list.append(0.0)
            em_list.append(0.0)

    avg_f1 = sum(f1_list) / len(f1_list) if f1_list else 0.0
    avg_em = sum(em_list) / len(em_list) if em_list else 0.0
    return avg_f1, avg_em
