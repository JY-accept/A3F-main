"""
Utility helpers for loading data and model weights.
"""

import json
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from a3f.utils.config import args


def load_data(data_path: str):
    """Load a JSON file and return the parsed object."""
    with open(data_path, encoding="utf-8") as f:
        return json.load(f)


def load_model(model_path: str):
    """Load a causal LM and its tokenizer from *model_path*.

    If ``args.model_name_or_path`` differs from *model_path* the base
    architecture is loaded from there and the fine-tuned weights are read
    from *model_path*.
    """
    base = args.model_name_or_path or model_path
    tokenizer = AutoTokenizer.from_pretrained(
        base,
        device_map="auto",
        padding_side="left",
        use_fast=False,
    )
    tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        base,
        device_map="auto",
        torch_dtype=torch.bfloat16,
    )

    if model_path is not None and model_path != base:
        state = torch.load(model_path, map_location="cpu")
        model.load_state_dict(state, strict=False)

    return model.eval(), tokenizer
