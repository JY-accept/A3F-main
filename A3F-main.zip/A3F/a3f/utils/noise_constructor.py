"""
Fine-grained noise construction utilities (Section 3.2 of the A3F paper).

Four noise categories are supported:
  - relevant      : highly related to query but contains false / outdated facts
  - counterfactual: highly related but with malformed / counterfactual content
  - redundant     : low relevance, provides little support for the answer
  - irrelevant    : completely unrelated to the query

All helper functions operate on lists of dicts with at minimum the keys:
  ``question``, ``answers``, ``best_ctx`` (golden text), ``ctxs`` (retrieved).
"""

import json
import random
from typing import List, Dict, Optional


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _rank_ctxs(ctxs: List[Dict]) -> List[Dict]:
    """Sort contexts so gold-containing passages come first."""
    with_ans = [c for c in ctxs if c.get("has_answer")]
    without_ans = [c for c in ctxs if not c.get("has_answer")]
    return with_ans + without_ans


# ─────────────────────────────────────────────────────────────────────────────
# Noise selectors
# ─────────────────────────────────────────────────────────────────────────────

def select_golden(data: List[Dict]) -> List[Dict]:
    """Return data dicts with *ctx* set to the gold document."""
    result = []
    for sample in data:
        best = sample.get("best_ctx")
        if isinstance(best, list):
            best = best[0]
        result.append({
            "question": sample["question"],
            "answers": sample["answers"],
            "ctx": best,
            "noise_type": "golden",
        })
    return result


def select_relevant_noise(data: List[Dict]) -> List[Dict]:
    """Relevant noise: contextually close to query but missing / corrupting
    the correct answer (corresponds to *ad_ctx[0]* in training data)."""
    result = []
    for sample in data:
        ad_ctxs = sample.get("ad_ctx", [])
        ctx = ad_ctxs[0] if ad_ctxs else sample.get("ctxs", [{}])[-1]
        if isinstance(ctx, str):
            ctx = {"text": ctx}
        result.append({
            "question": sample["question"],
            "answers": sample["answers"],
            "ctx": ctx,
            "noise_type": "relevant",
        })
    return result


def select_counterfactual_noise(data: List[Dict]) -> List[Dict]:
    """Counterfactual noise: high relevance but factually wrong content
    (corresponds to *ad_ctx[1]* / *counter_fac* in training data)."""
    result = []
    for sample in data:
        ad_ctxs = sample.get("ad_ctx", [])
        if len(ad_ctxs) >= 2:
            ctx = ad_ctxs[1]
        elif sample.get("counter_fac"):
            ctx = {"text": random.choice(sample["counter_fac"])}
        else:
            ctx = sample.get("ctxs", [{}])[-1]
        if isinstance(ctx, str):
            ctx = {"text": ctx}
        result.append({
            "question": sample["question"],
            "answers": sample["answers"],
            "ctx": ctx,
            "noise_type": "counterfactual",
        })
    return result


def select_redundant_noise(data: List[Dict]) -> List[Dict]:
    """Redundant noise: topic-related but provides little direct support
    (uses non-answer passages from the same query's retrieved set)."""
    result = []
    for sample in data:
        ctxs = _rank_ctxs(sample.get("ctxs", []))
        # Take a passage that does NOT contain the answer
        without_ans = [c for c in ctxs if not c.get("has_answer")]
        ctx = without_ans[0] if without_ans else ctxs[-1]
        if isinstance(ctx, str):
            ctx = {"text": ctx}
        result.append({
            "question": sample["question"],
            "answers": sample["answers"],
            "ctx": ctx,
            "noise_type": "redundant",
        })
    return result


def select_irrelevant_noise(data: List[Dict]) -> List[Dict]:
    """Irrelevant noise: passage sampled from a *different* query's context
    (corresponds to *ad_ctx[2]* in training data)."""
    result = []
    for i, sample in enumerate(data):
        ad_ctxs = sample.get("ad_ctx", [])
        if len(ad_ctxs) >= 3:
            ctx = ad_ctxs[2]
        else:
            # Fall back: random passage from a different sample
            other = random.choice(
                [s for j, s in enumerate(data) if j != i]
            )
            other_ctxs = other.get("ctxs", [{}])
            ctx = random.choice(other_ctxs) if other_ctxs else {}
        if isinstance(ctx, str):
            ctx = {"text": ctx}
        result.append({
            "question": sample["question"],
            "answers": sample["answers"],
            "ctx": ctx,
            "noise_type": "irrelevant",
        })
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Mixed-noise retrieval for robustness evaluation (Section 4.2.4)
# ─────────────────────────────────────────────────────────────────────────────

_NOISE_LABEL = {
    "relevant": 0,
    "counterfactual": 1,
    "redundant": 2,
    "irrelevant": 3,
}

NOISE_TYPES = ["relevant", "counterfactual", "redundant", "irrelevant"]


def select_noisy_retrieval(
    data: List[Dict],
    noise_ratio: float = 0.4,
    save_cache: Optional[str] = None,
) -> List[Dict]:
    """Build a mixed retrieval context per sample.

    Each sample's context list is assembled so that
    ``noise_ratio`` fraction of entries are randomly drawn
    from one of the four noise categories and the rest are golden.

    Args:
        data: Raw dataset samples.
        noise_ratio: Proportion of noisy passages (0.0 → all golden).
        save_cache: If given, serialise the result to this path.

    Returns:
        List of processed samples with ``ctx`` set to a list of dicts.
    """
    result = []
    for i, sample in enumerate(data):
        best = sample.get("best_ctx")
        if isinstance(best, list):
            best = best[0]

        ad_ctxs = sample.get("ad_ctx", [None, None, None])
        # Pad to at least 3 entries
        while len(ad_ctxs) < 3:
            ad_ctxs.append(None)

        # Map noise-type name → context dict
        noise_pool = {
            "relevant": ad_ctxs[0] if ad_ctxs[0] else best,
            "counterfactual": (
                ad_ctxs[1]
                if ad_ctxs[1]
                else ({"text": random.choice(sample["counter_fac"])}
                      if sample.get("counter_fac") else best)
            ),
            "redundant": (
                next(
                    (c for c in _rank_ctxs(sample.get("ctxs", []))
                     if not c.get("has_answer")),
                    best,
                )
            ),
            "irrelevant": (
                ad_ctxs[2]
                if ad_ctxs[2]
                else random.choice(
                    [s for j, s in enumerate(data) if j != i]
                ).get("ctxs", [best])[0]
            ),
        }
        # Normalise to dicts
        for key in noise_pool:
            if isinstance(noise_pool[key], str):
                noise_pool[key] = {"text": noise_pool[key]}

        # Build final context list
        num_docs = 4  # always present 4 passages to the LLM
        num_noise = max(1, round(num_docs * noise_ratio))
        num_gold = num_docs - num_noise

        ctx_list = [best] * num_gold
        noise_keys = random.choices(NOISE_TYPES, k=num_noise)
        for nk in noise_keys:
            ctx_list.append(noise_pool[nk])

        random.shuffle(ctx_list)

        result.append({
            "question": sample["question"],
            "answers": sample["answers"],
            "ctx": ctx_list,
        })

    if save_cache:
        with open(save_cache, "w", encoding="utf-8") as fh:
            json.dump(result, fh, ensure_ascii=False, indent=2)

    return result


def select_one_retrieve(
    data: List[Dict],
    retrieve_type: str = "best",
    save_cache: Optional[str] = None,
) -> List[Dict]:
    """Select a single context per sample for evaluation.

    Args:
        data: Raw dataset samples.
        retrieve_type: One of ``best``, ``relevant``, ``counterfactual``,
            ``redundant``, ``irrelevant``.
        save_cache: Optional path to serialise the result.
    """
    selectors = {
        "best": select_golden,
        "relevant": select_relevant_noise,
        "counterfactual": select_counterfactual_noise,
        "redundant": select_redundant_noise,
        "irrelevant": select_irrelevant_noise,
    }
    fn = selectors.get(retrieve_type, select_golden)
    result = fn(data)

    if save_cache:
        with open(save_cache, "w", encoding="utf-8") as fh:
            json.dump(result, fh, ensure_ascii=False, indent=2)

    return result
