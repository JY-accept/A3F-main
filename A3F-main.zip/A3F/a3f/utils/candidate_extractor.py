"""
Candidate Sentence Extractor (Section 3.3 of the A3F paper).

Two-stage extraction:
  1. Information-Gain (IG) scoring via the base LLM.
  2. KNN context expansion using Sentence-BERT cosine similarity.

The module is intentionally decoupled from the LLM trainer so it can be
used both during training (pre-processing) and at inference time.
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel


# ─────────────────────────────────────────────────────────────────────────────
# Sentence-BERT encoder (shared singleton, lazy-loaded)
# ─────────────────────────────────────────────────────────────────────────────

_SBERT_MODEL: Optional[AutoModel] = None
_SBERT_TOKENIZER: Optional[AutoTokenizer] = None
_SBERT_CHECKPOINT = "bert-base-uncased"


def _get_sbert():
    global _SBERT_MODEL, _SBERT_TOKENIZER
    if _SBERT_MODEL is None:
        _SBERT_TOKENIZER = AutoTokenizer.from_pretrained(_SBERT_CHECKPOINT)
        _SBERT_MODEL = AutoModel.from_pretrained(_SBERT_CHECKPOINT)
        _SBERT_MODEL.eval()
        if torch.cuda.is_available():
            _SBERT_MODEL = _SBERT_MODEL.cuda()
    return _SBERT_MODEL, _SBERT_TOKENIZER


def _mean_pool(token_embeddings: torch.Tensor,
               attention_mask: torch.Tensor) -> torch.Tensor:
    """Mean-pool token embeddings, respecting the attention mask."""
    expanded = attention_mask.unsqueeze(-1).float()
    return (token_embeddings * expanded).sum(1) / expanded.sum(1).clamp(min=1e-9)


@torch.no_grad()
def encode_sentences(sentences: List[str],
                     batch_size: int = 64) -> torch.Tensor:
    """Encode *sentences* with Sentence-BERT.

    Returns a 2-D float tensor of shape ``(N, hidden_size)`` normalised to
    unit length (suitable for cosine similarity via dot product).
    """
    model, tokenizer = _get_sbert()
    device = next(model.parameters()).device
    all_embeddings = []

    for start in range(0, len(sentences), batch_size):
        batch = sentences[start: start + batch_size]
        enc = tokenizer(
            batch,
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors="pt",
        )
        enc = {k: v.to(device) for k, v in enc.items()}
        out = model(**enc)
        emb = _mean_pool(out.last_hidden_state, enc["attention_mask"])
        emb = F.normalize(emb, p=2, dim=-1)
        all_embeddings.append(emb.cpu())

    return torch.cat(all_embeddings, dim=0)


# ─────────────────────────────────────────────────────────────────────────────
# Information-Gain approximation (Equations 1–2)
# ─────────────────────────────────────────────────────────────────────────────

@torch.no_grad()
def _entropy_from_lm(
    lm,
    tokenizer,
    prompt: str,
    top_k: int = 10,
    temperature: float = 0.1,
) -> float:
    """Approximate H(q) or H(q|s) by sampling top-K answers from the LLM."""
    device = next(lm.parameters()).device
    enc = tokenizer(prompt, return_tensors="pt", truncation=True,
                    max_length=512).to(device)
    out = lm.generate(
        **enc,
        max_new_tokens=32,
        num_return_sequences=top_k,
        do_sample=True,
        temperature=temperature,
        top_k=50,
        pad_token_id=tokenizer.eos_token_id,
    )
    # Simple uniform-weight entropy over unique generations
    texts = tokenizer.batch_decode(out[:, enc["input_ids"].shape[1]:],
                                   skip_special_tokens=True)
    unique = list(set(t.strip() for t in texts))
    n = len(unique) or 1
    p = 1.0 / n
    return -math.log(p)   # H = -Σ p log p  (uniform → -log(1/n) = log n)


def compute_information_gain(
    lm,
    tokenizer,
    query: str,
    sentence: str,
    top_k: int = 10,
    temperature: float = 0.1,
) -> float:
    """Compute IG(q, s) = H(q) - H(q|s) for a single sentence.

    Both entropies are approximated via top-K sampling from *lm*.
    """
    q_prompt = f"Question: {query} Short answer:"
    qs_prompt = f"Context: {sentence} Question: {query} Short answer:"

    h_q = _entropy_from_lm(lm, tokenizer, q_prompt, top_k, temperature)
    h_q_given_s = _entropy_from_lm(lm, tokenizer, qs_prompt, top_k, temperature)
    return h_q - h_q_given_s


# ─────────────────────────────────────────────────────────────────────────────
# KNN context expansion (Equations 3–4)
# ─────────────────────────────────────────────────────────────────────────────

def knn_expand(
    answer_sentences: List[str],
    candidate_sentences: List[str],
    k: int = 5,
) -> List[str]:
    """Expand *answer_sentences* with K nearest neighbours from *candidates*.

    Similarity is measured by Sentence-BERT cosine similarity (Equation 3).

    Returns the union S_c = S_a ∪ (∪_{s_j ∈ S_a} N(s_j))  (Equation 4).
    """
    if not answer_sentences or not candidate_sentences:
        return answer_sentences

    sa_emb = encode_sentences(answer_sentences)        # (|S_a|, D)
    cand_emb = encode_sentences(candidate_sentences)   # (|cands|, D)

    # Cosine similarity matrix  (|S_a|, |cands|)
    sim = torch.mm(sa_emb, cand_emb.T)

    selected_indices = set()
    actual_k = min(k, len(candidate_sentences))
    for row in sim:
        _, topk_idx = row.topk(actual_k)
        selected_indices.update(topk_idx.tolist())

    neighbours = [candidate_sentences[i] for i in selected_indices]
    # Return deduplicated union
    seen = set(answer_sentences)
    result = list(answer_sentences)
    for n in neighbours:
        if n not in seen:
            result.append(n)
            seen.add(n)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Adaptive noise weights (Equation 5 / Table 1)
# ─────────────────────────────────────────────────────────────────────────────

NOISE_WEIGHT_RANGES = {
    "relevant":      (0.10, 0.25),
    "counterfactual": (0.20, 0.40),
    "redundant":     (0.60, 0.85),
    "irrelevant":    (0.80, 1.00),
}


def compute_adaptive_weights(
    noise_sentences: List[Tuple[str, str]],   # [(sentence, noise_type), …]
    answer_sentences: List[str],
) -> List[float]:
    """Compute per-sentence adaptive weights w_i (Equation 5).

    Sentences that are *more* similar to answer-containing sentences receive
    *lower* weights (they are harder, confusable noise) and vice-versa.

    Args:
        noise_sentences: List of (text, noise_type) tuples.
        answer_sentences: The S_c candidate set.

    Returns:
        Normalised weight list of length ``len(noise_sentences)``.
    """
    if not noise_sentences or not answer_sentences:
        return [1.0 / max(len(noise_sentences), 1)] * len(noise_sentences)

    texts = [s for s, _ in noise_sentences]
    noise_emb = encode_sentences(texts)      # (N_noise, D)
    ans_emb = encode_sentences(answer_sentences)  # (N_ans, D)

    # Average similarity of each noise sentence to all S_c sentences
    sim = torch.mm(noise_emb, ans_emb.T).mean(dim=1)  # (N_noise,)

    # Inverse weighting: high similarity → low weight
    inv_sim = 1.0 - sim  # (N_noise,)
    inv_sim = inv_sim.clamp(min=1e-6)
    weights = (inv_sim / inv_sim.sum()).tolist()

    return weights


# ─────────────────────────────────────────────────────────────────────────────
# Public high-level extractor
# ─────────────────────────────────────────────────────────────────────────────

def extract_candidate_sentences(
    query: str,
    documents: List[str],
    lm=None,
    tokenizer=None,
    ig_threshold: float = 0.3,
    k: int = 5,
    top_n_per_doc: int = 5,
    use_ig: bool = True,
) -> List[str]:
    """Full Phase-1 + Phase-2 candidate extraction pipeline.

    Phase 1 – IG-based selection (requires *lm* and *tokenizer*).
    Phase 2 – KNN context expansion.

    When *use_ig* is ``False`` or *lm* is ``None`` the function skips IG
    scoring and simply tokenises every document into sentences, which is
    sufficient for fast data-preprocessing pipelines.

    Returns S_c (Equation 4).
    """
    import re

    # Tokenise all documents into sentences
    sent_re = re.compile(r"(?<=[.!?])\s+")
    all_sentences: List[str] = []
    for doc in documents:
        sents = [s.strip() for s in sent_re.split(doc) if s.strip()]
        all_sentences.extend(sents[:top_n_per_doc])

    if not all_sentences:
        return []

    # Phase 1: Information-Gain filtering
    if use_ig and lm is not None and tokenizer is not None:
        ig_scores = [
            compute_information_gain(lm, tokenizer, query, s)
            for s in all_sentences
        ]
        answer_sentences = [
            s for s, ig in zip(all_sentences, ig_scores) if ig >= ig_threshold
        ]
        # Fallback: keep top-3 if none pass threshold
        if not answer_sentences:
            sorted_pairs = sorted(
                zip(ig_scores, all_sentences), reverse=True
            )
            answer_sentences = [s for _, s in sorted_pairs[:3]]
    else:
        # Without IG, treat all sentences as candidates
        answer_sentences = all_sentences

    # Phase 2: KNN expansion (multi-hop queries only)
    is_multihop = len(query.split()) > 15
    if is_multihop:
        remaining = [s for s in all_sentences if s not in answer_sentences]
        s_c = knn_expand(answer_sentences, remaining, k=k)
    else:
        s_c = answer_sentences

    return s_c
