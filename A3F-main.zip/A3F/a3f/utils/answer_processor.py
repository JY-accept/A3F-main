"""
Prompt construction, answer generation, and answer extraction utilities
for the A3F framework.

Supported model families: LLaMA-3, DeepSeek-R1, Mistral, Qwen, ChatGLM.
Inference is performed with *vLLM* for efficiency.
"""

import re
from typing import List, Dict

from vllm import LLM, SamplingParams
from a3f.utils.config import args

# ─────────────────────────────────────────────────────────────────────────────
# Prompt templates
# ─────────────────────────────────────────────────────────────────────────────

_SYSTEM_PROMPT = (
    "You need to complete the question-and-answer pair following the format "
    "provided in the examples. The answer should be a short phrase or named "
    "entity, not a full sentence."
)

_EXAMPLES = [
    "\nExample 1:\nQuestion: What is the capital of France?\nAnswer: Paris.",
    "\nExample 2:\nQuestion: Who invented the telephone?\nAnswer: Alexander Graham Bell.",
    "\nExample 3:\nQuestion: Which element has the atomic number 1?\nAnswer: Hydrogen.",
]

_EXAMPLES_STR = "".join(_EXAMPLES)


def _build_prompt(model_path: str, system: str, context: str, query: str) -> str:
    """Return the full prompt string for a given model family."""
    mp = model_path.lower()
    if "llama" in mp:
        if context:
            return (
                f"<<SYS>>\n{system}\n<</SYS>>\n\n"
                f"[INST] {context}\n{query} [/INST]"
            )
        return f"<<SYS>>\n{system}\n<</SYS>>\n\n[INST] {query} [/INST]"
    if "mistral" in mp:
        body = f"{context}\n{query}" if context else query
        return f"<s>[INST] {system}\n{body} [/INST]"
    if "qwen" in mp:
        body = f"{context}\n{query}" if context else query
        return (
            f"<|im_start|>user\n{system}\n{body}<|im_end|>\n"
            "<|im_start|>assistant\n"
        )
    if "chatglm" in mp:
        body = f"{context}\n{query}" if context else query
        return f"{system}\n{body}"
    # Default / DeepSeek
    if context:
        return (
            f"<<SYS>>\n{system}\n<</SYS>>\n\n"
            f"[INST] {context}\n{query} [/INST]"
        )
    return f"<<SYS>>\n{system}\n<</SYS>>\n\n[INST] {query} [/INST]"


def _ctx_to_string(ctx) -> str:
    """Flatten a context object (str / dict / list) to a prompt string."""
    if ctx is None:
        return ""
    if isinstance(ctx, str):
        return ctx
    if isinstance(ctx, dict):
        return ctx.get("text", "")
    if isinstance(ctx, list):
        parts = []
        for i, c in enumerate(ctx, 1):
            text = c.get("text", "") if isinstance(c, dict) else str(c)
            parts.append(f"Context{i}: {text}")
        return "\n".join(parts)
    return str(ctx)


# ─────────────────────────────────────────────────────────────────────────────
# Answer extraction
# ─────────────────────────────────────────────────────────────────────────────

def extract_answer(text: str):
    """Extract the answer portion after 'Answer:'.

    Returns the extracted string, or ``False`` if nothing is found.
    """
    match = re.search(r"Answer:(.*)", text, re.DOTALL)
    if match:
        ans = match.group(1).strip()
        if ans.endswith("."):
            ans = ans[:-1]
        return ans if ans else False
    return False


# ─────────────────────────────────────────────────────────────────────────────
# vLLM-based batch inference helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_sampling_params() -> SamplingParams:
    return SamplingParams(
        max_tokens=512,
        top_k=50,
        top_p=0.6,
        temperature=0.3,
        repetition_penalty=1.0,
    )


def _run_vllm(model_path: str, prompts: List[str]) -> List[str]:
    """Run vLLM inference and return generated texts."""
    llm = LLM(
        model=model_path,
        tensor_parallel_size=1,
        tokenizer_mode="auto",
        trust_remote_code=True,
        dtype="bfloat16",
    )
    outputs = llm.generate(prompts, sampling_params=_get_sampling_params())
    return [out.outputs[0].text for out in outputs]


# ── Without retrieval ──────────────────────────────────────────────────────

def vllm_wo_retrieval(args, data: List[Dict]) -> List[str]:
    system = _SYSTEM_PROMPT + _EXAMPLES_STR
    prompts = [
        _build_prompt(
            args.test_model_name_or_path,
            system,
            "",
            f"Question: {s['question']}",
        )
        for s in data
    ]
    return _run_vllm(args.test_model_name_or_path, prompts)


# ── Single retrieved context ───────────────────────────────────────────────

def vllm_w_one_retrieval(args, data: List[Dict]) -> List[str]:
    system = _SYSTEM_PROMPT + _EXAMPLES_STR
    prompts = []
    for s in data:
        ctx_str = _ctx_to_string(s.get("ctx"))
        context_block = (
            f"The following context may help answer the question.\n{ctx_str}"
            if ctx_str else ""
        )
        prompts.append(
            _build_prompt(
                args.test_model_name_or_path,
                system,
                context_block,
                f"Question: {s['question']}",
            )
        )
    return _run_vllm(args.test_model_name_or_path, prompts)


# ── Mixed noisy retrieval ──────────────────────────────────────────────────

def vllm_w_noisy_retrieval(args, data: List[Dict]) -> List[str]:
    """Run inference on samples that carry a list of (possibly noisy) contexts."""
    system = _SYSTEM_PROMPT + _EXAMPLES_STR
    prompts = []
    for s in data:
        ctx = s.get("ctx", [])
        if not isinstance(ctx, list):
            ctx = [ctx]
        ctx_str = _ctx_to_string(ctx)
        context_block = (
            f"The following contexts may help answer the question.\n{ctx_str}"
            if ctx_str else ""
        )
        prompts.append(
            _build_prompt(
                args.test_model_name_or_path,
                system,
                context_block,
                f"Question: {s['question']}",
            )
        )
    return _run_vllm(args.test_model_name_or_path, prompts)
