"""
Configuration and argument parsing for A3F:
Adversarial-Aware Adaptive Filtering Framework.
"""

import random
import numpy as np
import torch
import argparse


def parse_args():
    parser = argparse.ArgumentParser(
        description="A3F: Adversarial-Aware Adaptive Filtering for noise-robust RAG"
    )

    # ── Paths ──────────────────────────────────────────────────────────────
    parser.add_argument("--log_path", type=str, default="logs",
                        help="Directory for TensorBoard logs and text logs.")
    parser.add_argument("--model_name_or_path", type=str, required=False,
                        help="Path to base LLM for training (e.g. LLaMA-3-7B).")
    parser.add_argument("--test_model_name_or_path", type=str, default=None,
                        help="Path to model checkpoint used for evaluation.")
    parser.add_argument("--train_file_path", type=str, default=None,
                        help="Path to JSON training data.")
    parser.add_argument("--validation_file_path", type=str, default=None,
                        help="Path to JSON validation data.")
    parser.add_argument("--test_data_path", type=str, default=None,
                        help="Path to JSON test data.")
    parser.add_argument("--output_dir", type=str, default="checkpoints",
                        help="Directory to save model checkpoints.")
    parser.add_argument("--train_data_cache", type=str,
                        default="a3f/data/temp.json",
                        help="Temporary file for processed training data.")
    parser.add_argument("--result_save", type=str, default=None,
                        help="Path to save evaluation results (JSON).")
    parser.add_argument("--selected_retrieve_cache", type=str, default=None,
                        help="Cache file for pre-selected retrieval contexts.")

    # ── Noise & retrieval settings ─────────────────────────────────────────
    parser.add_argument("--noise_ratio", type=float, default=None,
                        help="Proportion of noisy documents injected during testing.")
    parser.add_argument("--retrieve_type", type=str, default="best",
                        choices=["best", "relevant", "counterfactual",
                                 "redundant", "irrelevant"],
                        help="Type of retrieval context to use during testing.")

    # ── A3F-specific hyperparameters ───────────────────────────────────────
    parser.add_argument("--knn_k", type=int, default=5,
                        help="Number of nearest neighbours in KNN clustering (Section 3.3).")
    parser.add_argument("--ig_threshold", type=float, default=0.3,
                        help="Information-gain threshold τ for candidate sentence selection.")
    parser.add_argument("--w_gen", type=float, default=0.7,
                        help="Weight for generative loss in joint objective (w_gen).")
    parser.add_argument("--w_cls", type=float, default=0.3,
                        help="Weight for classification loss in joint objective (w_cls).")
    parser.add_argument("--w_reg", type=float, default=0.5,
                        help="Regularisation weight w_reg in Eq. (12).")

    # ── Training hyperparameters ───────────────────────────────────────────
    parser.add_argument("--do_train", action="store_true")
    parser.add_argument("--do_validation", action="store_true")
    parser.add_argument("--num_train_epochs", type=int, default=3)
    parser.add_argument("--per_device_train_batch_size", type=int, default=1)
    parser.add_argument("--per_device_eval_batch_size", type=int, default=4)
    parser.add_argument("--learning_rate", type=float, default=5e-6,
                        help="AdamW learning rate.")
    parser.add_argument("--max_length", type=int, default=4096,
                        help="Maximum token sequence length.")
    parser.add_argument("--gradient_accumulation_steps", type=int, default=4)
    parser.add_argument("--max_train_steps", type=int, default=None)
    parser.add_argument("--checkpointing_step", type=int, default=600,
                        help="Save checkpoint every N gradient steps.")
    parser.add_argument("--training_stage_num", type=int, default=4,
                        help="Number of noise types (always 4 for A3F).")

    # ── Evaluation flags ───────────────────────────────────────────────────
    parser.add_argument("--wo_retrieval", action="store_true",
                        help="Evaluate without any retrieved context.")
    parser.add_argument("--w_one_retrieval", action="store_true",
                        help="Evaluate with a single retrieved context.")
    parser.add_argument("--w_noisy_retrieval", action="store_true",
                        help="Evaluate with mixed noisy retrieval contexts.")
    parser.add_argument("--multi_eval", action="store_true",
                        help="Use multiple in-context examples during evaluation.")

    # ── Reproducibility ────────────────────────────────────────────────────
    parser.add_argument("--seed", type=int, default=42)

    return parser.parse_args()


def setup_seed(seed: int) -> None:
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


args = parse_args()
setup_seed(args.seed)
