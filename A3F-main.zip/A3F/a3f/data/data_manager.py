"""
DataManager for the A3F framework.

Responsibilities:
  - Tokenise and collate training batches with all four noise types.
  - Build the four prompt variants required by the joint-optimisation loop.
  - Expose ``infer_generate`` for validation-time decoding.

Training data format (JSON list):
  Each element must contain:
    ``question``   : str
    ``answers``    : list[str]
    ``best_ctx``   : dict | list[dict]  – golden context
    ``ad_ctx``     : list[dict | str]   – [relevant, counterfactual, irrelevant]
                                          noise contexts (at least 1 entry)

  Optional:
    ``counter_fac``: list[str]          – counterfactual passages
    ``ctxs``       : list[dict]         – DPR-retrieved passages
"""

from __future__ import annotations

import json
import random
from typing import List, Dict

import torch
from torch.utils.data import DataLoader
from datasets import load_dataset
from transformers import (
    AutoConfig,
    AutoTokenizer,
    LlamaTokenizer,
)

from a3f.utils.config import args


# ─────────────────────────────────────────────────────────────────────────────
# Prompt templates (kept consistent with answer_processor.py)
# ─────────────────────────────────────────────────────────────────────────────

_SYS = (
    "You need to complete the question-and-answer pair following the format "
    "provided in the examples. The answer should be a short phrase or named "
    "entity, not a full sentence."
    "\nExample 1:\nQuestion: What is the capital of France?\nAnswer: Paris."
    "\nExample 2:\nQuestion: Who invented the telephone?\nAnswer: Alexander Graham Bell."
    "\nExample 3:\nQuestion: Which element has the atomic number 1?\nAnswer: Hydrogen."
)

_PROMPT_WITH_CTX = (
    "<<SYS>>\n{system}\n<</SYS>>\n\n"
    "[INST] {context}\n{query} [/INST]"
)
_PROMPT_NO_CTX = (
    "<<SYS>>\n{system}\n<</SYS>>\n\n"
    "[INST] {query} [/INST]"
)

# Four noise-type names aligned with the paper
NOISE_TYPES = ["relevant", "counterfactual", "redundant", "irrelevant"]


def _ctx_text(ctx) -> str:
    if ctx is None:
        return ""
    if isinstance(ctx, str):
        return ctx
    if isinstance(ctx, dict):
        return ctx.get("text", "")
    if isinstance(ctx, list) and ctx:
        return _ctx_text(ctx[0])
    return ""


def _make_prompt(context_text: str, question: str) -> str:
    if context_text:
        ctx_block = (
            f"The following context may help answer the question.\n{context_text}"
        )
        return _PROMPT_WITH_CTX.format(
            system=_SYS, context=ctx_block, query=f"Question: {question}"
        )
    return _PROMPT_NO_CTX.format(system=_SYS, query=f"Question: {question}")


# ─────────────────────────────────────────────────────────────────────────────
# DataManager
# ─────────────────────────────────────────────────────────────────────────────

class DataManager:
    """Tokeniser + data-loading helper for A3F training."""

    def __init__(self, config: AutoConfig, training_stage: int,
                 tokenizer_path: str):
        self.config = config
        self.training_stage = training_stage  # always 4
        self.max_length = args.max_length

        arch = config.architectures[0].lower() if config.architectures else ""
        if "llama" in arch:
            self.tokenizer = LlamaTokenizer.from_pretrained(
                tokenizer_path, use_fast=False
            )
            self.tokenizer.unk_token = "<unk>"
            self.tokenizer.bos_token = "<s>"
            self.tokenizer.eos_token = "</s>"
        else:
            self.tokenizer = AutoTokenizer.from_pretrained(
                tokenizer_path, use_fast=False
            )
        self.tokenizer.pad_token = self.tokenizer.eos_token

    # ── Batch decoder ────────────────────────────────────────────────────────

    def batch_decode(self, token_ids) -> List[str]:
        return self.tokenizer.batch_decode(token_ids, skip_special_tokens=True)

    # ── Data collator ────────────────────────────────────────────────────────

    def train_data_collator(self, features: List[Dict]):
        """Collate a batch of training samples into the tensor format
        expected by ``A3FTrainer.compute_loss``.

        Each sample contributes *training_stage* (= 4) rows, one per noise
        type:  relevant (0), counterfactual (1), redundant (2), irrelevant (3).
        The five-column batch tensor has shape ``[batch, 4, seq_len]``.
        """
        batch_size = len(features)
        stage = self.training_stage  # 4

        origin_state = (self.tokenizer.padding_side,
                        self.tokenizer.truncation_side)
        self.tokenizer.truncation_side = "left"

        prompts: List[str] = []
        answers: List[str] = []
        # noise_labels[i % stage] gives the noise-type index for row i
        noise_labels: List[int] = []

        for feature in features:
            for noise_idx, noise_key in enumerate(NOISE_TYPES):
                prompts.append(feature[noise_key][0])
                answers.append(feature["answer"])
                noise_labels.append(noise_idx)

        # Truncate prompts to leave room for the answer
        prompts_truncated = self.batch_decode(
            self.tokenizer(
                prompts,
                max_length=self.max_length - 128,
                truncation=True,
                add_special_tokens=True,
            )["input_ids"]
        )

        prompt_ids = self.tokenizer(
            prompts_truncated, add_special_tokens=True
        )["input_ids"]
        prefix_lens = [len(ids) - 1 for ids in prompt_ids]

        self.tokenizer.padding_side = "right"
        self.tokenizer.truncation_side = "right"

        full_texts = [p + " " + a for p, a in zip(prompts_truncated, answers)]

        batch = self.tokenizer(
            full_texts,
            padding=True,
            max_length=self.max_length,
            truncation=True,
            add_special_tokens=True,
            return_tensors="pt",
        )

        seq_len = batch["attention_mask"].shape[1]

        # Build prefix mask: 1 for prompt tokens, 0 for answer tokens
        prefix_mask = torch.tensor([
            [1 if i < plen else 0 for i in range(seq_len)]
            for plen in prefix_lens
        ])

        batch["prefix_mask"] = prefix_mask
        batch["labels"] = batch["input_ids"].clone().detach()
        batch["noise_labels"] = torch.tensor(noise_labels, dtype=torch.long)

        # Reshape to [batch_size, stage, seq_len]
        for key in ["input_ids", "attention_mask", "prefix_mask", "labels"]:
            batch[key] = batch[key].view(batch_size, stage, -1)
        batch["noise_labels"] = batch["noise_labels"].view(batch_size, stage)

        self.tokenizer.padding_side, self.tokenizer.truncation_side = origin_state
        return batch

    # ── Data loading ─────────────────────────────────────────────────────────

    def load_train_data(
        self,
        data_file_path: str,
        data_collator=None,
    ) -> DataLoader:
        """Read raw training JSON, build prompt variants, save cache,
        and return a DataLoader."""
        if data_collator is None:
            data_collator = self.train_data_collator

        with open(data_file_path, encoding="utf-8") as fh:
            raw_data = json.load(fh)

        processed = []
        for i, sample in enumerate(raw_data):
            best_ctx = sample.get("best_ctx")
            ad_ctxs = sample.get("ad_ctx", [])
            while len(ad_ctxs) < 3:
                ad_ctxs.append(None)

            question = sample["question"]
            best_text = _ctx_text(best_ctx)
            rel_text = _ctx_text(ad_ctxs[0]) or best_text
            cf_text = (
                _ctx_text(ad_ctxs[1])
                or (random.choice(sample["counter_fac"])
                    if sample.get("counter_fac") else best_text)
            )
            # Redundant: same-topic passage without the answer
            red_ctx = next(
                (c for c in sample.get("ctxs", [])
                 if not c.get("has_answer")),
                ad_ctxs[0] or best_ctx,
            )
            red_text = _ctx_text(red_ctx)
            irr_text = _ctx_text(ad_ctxs[2]) or best_text

            answer = "\nAnswer: " + (
                sample["answers"][0]
                if isinstance(sample["answers"], list)
                else sample["answers"]
            )

            processed.append({
                "relevant":      [_make_prompt(rel_text, question)],
                "counterfactual": [_make_prompt(cf_text, question)],
                "redundant":     [_make_prompt(red_text, question)],
                "irrelevant":    [_make_prompt(irr_text, question)],
                "answer":        answer,
            })

        cache_path = args.train_data_cache
        with open(cache_path, "w", encoding="utf-8") as fh:
            json.dump(processed, fh, ensure_ascii=False, indent=2)

        raw_ds = load_dataset("json", data_files=cache_path)
        return DataLoader(
            raw_ds["train"],
            shuffle=True,
            collate_fn=data_collator,
            batch_size=args.per_device_train_batch_size,
        )

    # ── Validation decoding ───────────────────────────────────────────────────

    @torch.no_grad()
    def infer_generate(self, model, prompts: List[str]) -> List[str]:
        """Generate short answers for a list of prompt strings."""
        origin_state = (self.tokenizer.padding_side,
                        self.tokenizer.truncation_side)
        self.tokenizer.padding_side = "left"
        self.tokenizer.truncation_side = "left"

        truncated = self.batch_decode(
            self.tokenizer(
                prompts,
                max_length=self.max_length - 128,
                truncation=True,
                add_special_tokens=True,
            )["input_ids"]
        )

        batch = self.tokenizer(
            truncated,
            padding=True,
            max_length=self.max_length - 128,
            truncation=True,
            add_special_tokens=True,
            return_tensors="pt",
        ).to(model.device)

        generated = model.generate(
            **batch,
            max_new_tokens=128,
            eos_token_id=self.tokenizer.eos_token_id,
            bos_token_id=self.tokenizer.bos_token_id,
            pad_token_id=self.tokenizer.pad_token_id,
            num_beams=1,
            do_sample=False,
            top_k=50,
            top_p=0.6,
            temperature=0.3,
            repetition_penalty=1.0,
        )

        decoded = self.batch_decode(generated)
        results = []
        for trunc, full in zip(truncated, decoded):
            suffix = full.replace(trunc.rstrip(), "").strip()
            results.append(suffix)

        self.tokenizer.padding_side, self.tokenizer.truncation_side = origin_state
        return results
