"""
Exact-Match and F1 evaluation metrics for open-domain QA.
"""

import re
import string
from collections import Counter
from typing import List, Dict


# ─────────────────────────────────────────────────────────────────────────────
# Text normalisation
# ─────────────────────────────────────────────────────────────────────────────

def _remove_articles(text: str) -> str:
    return re.sub(r"\b(a|an|the)\b", " ", text)


def _white_space_fix(text: str) -> str:
    return " ".join(text.split())


def _remove_punc(text: str) -> str:
    return "".join(ch for ch in text if ch not in set(string.punctuation))


def _lower(text: str) -> str:
    return text.lower()


def normalize_answer(s: str) -> str:
    """Apply canonical normalisation to an answer string."""
    # Remove possessives / quotation marks
    s = re.sub(r"'", " ", s)
    s = re.sub(r'"', " ", s)
    for char in ["《", "》", "〈", "〉", "<", ">"]:
        s = s.replace(char, " ")
    s = re.sub(r"[\(\)]", " ", s)
    return _white_space_fix(_remove_punc(_lower(_remove_articles(s))))


# ─────────────────────────────────────────────────────────────────────────────
# Metric computation
# ─────────────────────────────────────────────────────────────────────────────

def f1_score(prediction: str, ground_truth: str) -> float:
    """Token-level F1 between *prediction* and *ground_truth*."""
    pred_tokens = normalize_answer(prediction).split()
    gold_tokens = normalize_answer(ground_truth).split()
    common = Counter(pred_tokens) & Counter(gold_tokens)
    num_same = sum(common.values())
    if num_same == 0:
        return 0.0
    precision = num_same / len(pred_tokens)
    recall = num_same / len(gold_tokens)
    return (2 * precision * recall) / (precision + recall)


def exact_match_score(prediction: str, ground_truths: List[str]) -> bool:
    """Return ``True`` if *prediction* exactly matches any gold answer."""
    norm_pred = normalize_answer(prediction)
    return any(norm_pred == normalize_answer(gt) for gt in ground_truths)


def compute_metrics(predicted_answer: str,
                    ground_truth_answers: List[str]) -> Dict[str, float]:
    """Return ``{"em": float, "f1": float}`` for a single prediction."""
    em = 1.0 if exact_match_score(predicted_answer, ground_truth_answers) else 0.0
    f1_scores = [f1_score(predicted_answer, gt) for gt in ground_truth_answers]
    return {"em": em, "f1": max(f1_scores) if f1_scores else 0.0}
