"""
A3F Trainer (Sections 3.3 and 3.4 of the A3F paper).

Key components:
  ─ NoiseClassificationHead : 4-class linear head on the last hidden state.
  ─ A3FModel                : Causal LM + noise classification head.
  ─ A3FTrainer              : Training loop with joint-optimisation loss.

Loss decomposition (Equation 16):
  L_A3F = w_gen · L_generative + w_cls · L_cls

where:
  L_generative = L̄_average + w_reg · L_reg          (Equations 10–12)
  L_cls        = cross-entropy noise classification  (Equation 15)
"""

from __future__ import annotations

import gc
import math
import os
from datetime import timedelta
from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F
from accelerate import Accelerator
from accelerate.logging import get_logger
from accelerate.utils import InitProcessGroupKwargs
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
)

from a3f.data.data_manager import DataManager
from a3f.evaluate.evaluator import infer_evaluate
from a3f.utils.config import args


logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Noise classification head  (Equation 13–15)
# ─────────────────────────────────────────────────────────────────────────────

class NoiseClassificationHead(nn.Module):
    """4-class linear classification head on top of the last hidden state.

    Implements the auxiliary noise-classification task described in Section 3.4.
    The head is placed on top of the base LLM's last hidden state ``h_T`` and
    jointly optimised with the generative objective.
    """

    def __init__(self, hidden_size: int, num_noise_types: int = 4,
                 dropout_prob: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout_prob)
        # Linear layer: z = W_cls · h_T + b_cls  (Equation 13)
        self.linear = nn.Linear(hidden_size, num_noise_types)

    def forward(self, last_hidden_state: torch.Tensor) -> torch.Tensor:
        """Args:
            last_hidden_state: ``[batch, seq_len, hidden_size]``

        Returns:
            logits: ``[batch, num_noise_types]``
        """
        # Take the last token's hidden state as the sequence representation
        h_T = last_hidden_state[:, -1, :]   # [batch, hidden_size]
        h_T = self.dropout(h_T)
        return self.linear(h_T.to(self.linear.weight.dtype))


# ─────────────────────────────────────────────────────────────────────────────
# A3F model: causal LM + classification head
# ─────────────────────────────────────────────────────────────────────────────

class A3FModel(nn.Module):
    """Wraps a causal LM with an additional noise classification head.

    The two heads share the same encoder (base LLM), consistent with the
    joint-optimisation design in Section 3.4.
    """

    def __init__(self, pretrained_model: AutoModelForCausalLM,
                 hidden_size: int):
        super().__init__()
        self.pretrained_model = pretrained_model
        self.cls_head = NoiseClassificationHead(hidden_size)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        **kwargs,
    ):
        """Forward pass returning (lm_logits, hidden_states).

        ``output_hidden_states=True`` is always enabled so the classification
        head can access the last hidden state.
        """
        out = self.pretrained_model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=True,
            **kwargs,
        )
        lm_logits = out.logits                   # [batch, seq_len, vocab]
        last_hidden = out.hidden_states[-1]       # [batch, seq_len, hidden]
        cls_logits = self.cls_head(last_hidden)  # [batch, 4]
        return lm_logits, cls_logits

    def generate(self, *args, **kwargs):
        return self.pretrained_model.generate(*args, **kwargs)

    def state_dict(self, *args, **kwargs):
        state = self.pretrained_model.state_dict(*args, **kwargs)
        for k, v in self.cls_head.state_dict(*args, **kwargs).items():
            state[f"cls_head.{k}"] = v
        return state


# ─────────────────────────────────────────────────────────────────────────────
# A3F Trainer
# ─────────────────────────────────────────────────────────────────────────────

class A3FTrainer:
    """Orchestrates the full A3F training loop.

    Loss computation follows Algorithms 2–3 in the paper:
      1. Per-noise-type generative loss (NLL).
      2. Adaptive weighted average  L̄_average  (Equation 10).
      3. Regularisation term         L_reg      (Equation 11).
      4. Combined generative loss    L_gen      (Equation 12).
      5. Classification loss         L_cls      (Equation 15).
      6. Joint loss                  L_A3F      (Equation 16).
    """

    def __init__(self, accelerator: Accelerator):
        self.accelerator = accelerator
        self.model_path = args.model_name_or_path

        self.model_config = AutoConfig.from_pretrained(self.model_path)
        self.data_manager = DataManager(
            self.model_config,
            args.training_stage_num,
            self.model_path,
        )

        base_lm = AutoModelForCausalLM.from_pretrained(
            self.model_path,
            config=self.model_config,
            torch_dtype=torch.bfloat16,
        )
        base_lm.resize_token_embeddings(len(self.data_manager.tokenizer))

        hidden_size = self.model_config.hidden_size
        self.model = A3FModel(base_lm, hidden_size)

    # ── Loss helpers ──────────────────────────────────────────────────────────

    def _generative_loss(
        self,
        lm_logits: torch.Tensor,     # [batch, seq_len, vocab]
        labels: torch.Tensor,        # [batch, seq_len]
        attention_mask: torch.Tensor,
        prefix_mask: torch.Tensor,   # 1 for prompt tokens, 0 for answer
    ) -> torch.Tensor:
        """Compute per-sample auto-regressive NLL (Equation 9).

        Returns a 1-D tensor of shape ``[batch]``.
        """
        batch_size = lm_logits.shape[0]

        shift_logits = lm_logits[..., :-1, :].contiguous()   # [B, L-1, V]
        shift_logits = F.log_softmax(shift_logits, dim=-1)

        # Mask: only answer tokens contribute to the loss
        answer_mask = (attention_mask & ~prefix_mask)[..., :-1]  # [B, L-1]

        shift_labels = labels[..., 1:].unsqueeze(-1)              # [B, L-1, 1]
        token_nll = torch.gather(shift_logits, dim=2,
                                 index=shift_labels).squeeze(-1)  # [B, L-1]
        token_nll[answer_mask != 1] = 0.0

        total_nll = token_nll.sum(dim=-1)                         # [B]
        denom = answer_mask.float().sum(dim=-1).clamp(min=1)      # [B]
        return -(total_nll / denom)                               # [B] (positive)

    def _regularisation_loss(
        self, per_noise_losses: torch.Tensor  # [batch, 4]
    ) -> torch.Tensor:
        """L_reg = ||L̄_max − L̄_min||^2_2  (Equation 11)."""
        l_max = per_noise_losses.max(dim=1).values   # [batch]
        l_min = per_noise_losses.min(dim=1).values   # [batch]
        return ((l_max - l_min) ** 2).mean()

    def compute_loss(
        self,
        model: A3FModel,
        batch: dict,
        print_loss: List[List[float]],
    ) -> None:
        """Compute L_A3F and call ``accelerator.backward``.

        *batch* layout (after collation):
          input_ids      [B, 4, L]
          attention_mask [B, 4, L]
          prefix_mask    [B, 4, L]
          labels         [B, 4, L]
          noise_labels   [B, 4]  – ground-truth noise-type indices (0–3)
        """
        batch_size = batch["labels"].shape[0]
        stage = batch["labels"].shape[1]  # 4

        # ── Per-noise-type forward passes ───────────────────────────────────
        per_noise_nll: List[torch.Tensor] = []    # each [B]
        cls_logits_list: List[torch.Tensor] = []  # each [B, 4]

        for t in range(stage):
            sub = {
                "input_ids":      batch["input_ids"][:, t, :],
                "attention_mask": batch["attention_mask"][:, t, :],
            }
            lm_logits, cls_logits = model(**sub)
            cls_logits_list.append(cls_logits)

            nll = self._generative_loss(
                lm_logits,
                batch["labels"][:, t, :],
                batch["attention_mask"][:, t, :],
                batch["prefix_mask"][:, t, :],
            )
            per_noise_nll.append(nll)

        per_noise_losses = torch.stack(per_noise_nll, dim=1)  # [B, 4]

        # ── Adaptive weights (Table 1 / Equation 5) ─────────────────────────
        # Fixed default weights matching paper ranges (mid-point of each range)
        w_default = torch.tensor(
            [0.175, 0.300, 0.725, 0.900],   # rel, cf, red, irr
            device=per_noise_losses.device, dtype=per_noise_losses.dtype
        )
        w_default = w_default / w_default.sum()

        # ── L̄_average  (Equation 10) ─────────────────────────────────────
        l_avg = (per_noise_losses * w_default.unsqueeze(0)).sum(dim=1).mean()

        # ── L_reg  (Equation 11) ─────────────────────────────────────────────
        l_reg = self._regularisation_loss(per_noise_losses)

        # ── L_generative  (Equation 12) ──────────────────────────────────────
        l_generative = l_avg + args.w_reg * l_reg

        # ── L_cls  (Equation 15) ─────────────────────────────────────────────
        # Stack all cls logits and corresponding ground-truth labels
        cls_logits_all = torch.cat(cls_logits_list, dim=0)  # [B*4, 4]
        # Ground-truth labels from batch (flattened row-major)
        gt_labels = batch["noise_labels"].view(-1)           # [B*4]
        cls_criterion = nn.CrossEntropyLoss()
        l_cls = cls_criterion(cls_logits_all, gt_labels.to(cls_logits_all.device))

        # ── L_A3F  (Equation 16) ─────────────────────────────────────────────
        l_a3f = args.w_gen * l_generative + args.w_cls * l_cls

        # ── Logging ──────────────────────────────────────────────────────────
        print_loss[0].append(l_generative.item())
        print_loss[1].append(l_cls.item())
        print_loss[2].append(l_reg.item())
        print_loss[3].append(l_a3f.item())

        self.accelerator.backward(l_a3f)

    # ── Data preparation ─────────────────────────────────────────────────────

    def _make_dataloader(self, train_file_path: str):
        return self.data_manager.load_train_data(
            data_file_path=train_file_path,
            data_collator=self.data_manager.train_data_collator,
        )

    # ── Training entry point ─────────────────────────────────────────────────

    def train(self):
        """Full training loop (Algorithm 3)."""
        import json as _json

        with open(args.train_file_path, encoding="utf-8") as fh:
            dataset_length = len(_json.load(fh))

        optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=args.learning_rate
        )

        placeholder_dl = self._make_dataloader(args.train_file_path)

        model, optimizer, _ = self.accelerator.prepare(
            self.model, optimizer, placeholder_dl
        )
        self.model = None

        if args.max_train_steps is None:
            steps_per_epoch = math.ceil(
                math.ceil(dataset_length / args.per_device_train_batch_size)
                / args.gradient_accumulation_steps
            )
            args.max_train_steps = steps_per_epoch * args.num_train_epochs

        total_steps = math.ceil(
            math.ceil(
                math.ceil(dataset_length / args.per_device_train_batch_size)
                / self.accelerator.num_processes
            )
            / args.gradient_accumulation_steps
        ) * args.num_train_epochs

        progress_bar = tqdm(
            range(total_steps),
            disable=not self.accelerator.is_local_main_process,
        )

        if self.accelerator.is_main_process:
            writer = SummaryWriter(args.log_path)
            os.makedirs(args.output_dir, exist_ok=True)

        completed_steps = 0
        best_step = -1
        best_f1 = float("-inf")

        for epoch in range(args.num_train_epochs):
            self.accelerator.print(f"\n── Epoch {epoch} ──")
            torch.cuda.empty_cache()
            dataloader = self.accelerator.prepare(
                self._make_dataloader(args.train_file_path)
            )

            # 4 slots: [gen_loss, cls_loss, reg_loss, total_loss]
            print_loss: List[List[float]] = [[] for _ in range(4)]

            for step, batch in enumerate(dataloader):
                model.train()
                with self.accelerator.accumulate(model):
                    self.compute_loss(model, batch, print_loss)
                    optimizer.step()
                    optimizer.zero_grad()

                if self.accelerator.sync_gradients:
                    completed_steps += 1
                    progress_bar.update(1)
                    self.accelerator.wait_for_everyone()

                    if self.accelerator.is_main_process:
                        avg = lambda lst: sum(lst) / max(len(lst), 1)
                        l_gen  = avg(print_loss[0])
                        l_cls  = avg(print_loss[1])
                        l_reg  = avg(print_loss[2])
                        l_tot  = avg(print_loss[3])

                        writer.add_scalar("loss/generative", l_gen, completed_steps)
                        writer.add_scalar("loss/classification", l_cls, completed_steps)
                        writer.add_scalar("loss/regularisation", l_reg, completed_steps)
                        writer.add_scalar("loss/total", l_tot, completed_steps)

                        logger.info(
                            f"Step {completed_steps} | "
                            f"total={l_tot:.4f} gen={l_gen:.4f} "
                            f"cls={l_cls:.4f} reg={l_reg:.4f}"
                        )

                        if args.do_validation and (
                            completed_steps % args.checkpointing_step == 0
                            or step == len(dataloader) - 1
                        ):
                            m = self.accelerator.unwrap_model(model)
                            val_data = self._run_validation(m)
                            f1, em = infer_evaluate(val_data)
                            logger.info(
                                f"Step {completed_steps} | val f1={f1:.4f} em={em:.4f}"
                            )
                            if f1 > best_f1:
                                best_f1 = f1
                                best_step = completed_steps
                            self._save_checkpoint(
                                m,
                                self.data_manager.tokenizer,
                                os.path.join(
                                    args.output_dir,
                                    f"step_{completed_steps}.bin",
                                ),
                            )
                            m = None

                    print_loss = [[] for _ in range(4)]
                    self.accelerator.wait_for_everyone()

            torch.cuda.empty_cache()
            self.accelerator.wait_for_everyone()

            if self.accelerator.is_main_process:
                m = self.accelerator.unwrap_model(model)
                self._save_checkpoint(
                    m,
                    self.data_manager.tokenizer,
                    os.path.join(args.output_dir, f"epoch_{epoch}.bin"),
                )
                logger.info(f"Epoch {epoch} checkpoint saved.")
                m = None

        if args.do_validation and self.accelerator.is_main_process:
            best_ckpt = os.path.join(args.output_dir, f"step_{best_step}.bin")
            link = os.path.join(args.output_dir, "best_checkpoint.bin")
            if not os.path.exists(link):
                os.symlink(best_ckpt, link)
            logger.info(f"Best checkpoint: step_{best_step}")

        if self.accelerator.is_main_process:
            writer.close()

        return self.accelerator.unwrap_model(model)

    # ── Validation helper ─────────────────────────────────────────────────────

    def _run_validation(self, model):
        """Run greedy decoding on the validation set (first 500 samples)."""
        import json as _json

        model.eval()
        with open(args.validation_file_path, encoding="utf-8") as fh:
            val_data = _json.load(fh)[:500]

        batch_size = args.per_device_eval_batch_size
        for start in range(0, len(val_data), batch_size):
            chunk = val_data[start: start + batch_size]
            prompts = [s["question"] for s in chunk]
            preds = self.data_manager.infer_generate(
                model.pretrained_model, prompts
            )
            for sample, pred in zip(chunk, preds):
                sample["infer"] = pred

        model.train()
        return val_data

    # ── Checkpoint saver ──────────────────────────────────────────────────────

    def _save_checkpoint(self, model, tokenizer, path: str) -> None:
        if path:
            torch.save(model.pretrained_model.state_dict(), path)
            logger.info(f"Checkpoint saved to {path}")
        else:
            logger.error("No save path specified.")
